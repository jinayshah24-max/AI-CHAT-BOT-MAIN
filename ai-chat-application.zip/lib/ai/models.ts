/**
 * AI Model Configuration
 *
 * Uses the Google Gemini provider via @ai-sdk/google.
 * Get a free API key at https://aistudio.google.com/apikey
 * Add it as GOOGLE_GENERATIVE_AI_API_KEY in the Vars section.
 */

export interface AIModel {
  id: string
  name: string
  provider: string
  description: string
  contextWindow?: string
  maxOutput?: string
}

export interface ModelProvider {
  id: string
  name: string
  models: AIModel[]
}

export const MODEL_PROVIDERS: ModelProvider[] = [
  {
    id: "google",
    name: "Google Gemini",
    models: [
      {
        id: "google/gemini-2.5-flash",
        name: "Gemini 2.5 Flash",
        provider: "Google",
        description: "Fast and versatile, great for everyday tasks",
        contextWindow: "1M tokens",
        maxOutput: "8K tokens",
      },
      {
        id: "google/gemini-2.5-pro",
        name: "Gemini 2.5 Pro",
        provider: "Google",
        description: "Most capable Gemini model for complex reasoning",
        contextWindow: "1M tokens",
        maxOutput: "8K tokens",
      },
      {
        id: "google/gemini-2.0-flash",
        name: "Gemini 2.0 Flash",
        provider: "Google",
        description: "Previous generation, fast and reliable",
        contextWindow: "1M tokens",
        maxOutput: "8K tokens",
      },
      {
        id: "google/gemini-2.0-flash-lite",
        name: "Gemini 2.0 Flash Lite",
        provider: "Google",
        description: "Lightweight model, fastest responses",
        contextWindow: "1M tokens",
        maxOutput: "8K tokens",
      },
    ],
  },
]

export const DEFAULT_MODEL_ID = "google/gemini-2.5-flash"

/**
 * Returns a flat list of all available models across all providers.
 */
export function getAllModels(): AIModel[] {
  return MODEL_PROVIDERS.flatMap((p) => p.models)
}

/**
 * Finds a model by its ID string.
 */
export function getModelById(id: string): AIModel | undefined {
  return getAllModels().find((m) => m.id === id)
}
