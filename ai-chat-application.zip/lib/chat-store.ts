/**
 * Chat Store
 *
 * Client-side state management for chat conversations.
 * Uses a simple pub/sub pattern with React state.
 * In production, this would be backed by a database (e.g., PostgreSQL via Drizzle ORM).
 *
 * Architecture note:
 * - Each chat has a unique ID, a title, and a model association
 * - The actual messages are managed by useChat from @ai-sdk/react
 * - This store only tracks metadata (titles, ordering, active model)
 */

export interface ChatMetadata {
  id: string
  title: string
  modelId: string
  createdAt: number
  updatedAt: number
}

/**
 * Generates a unique ID for new chats.
 */
export function generateChatId(): string {
  return `chat_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`
}

/**
 * Generates a title from the first user message.
 * Truncates to a reasonable length for sidebar display.
 */
export function generateTitle(firstMessage: string): string {
  const cleaned = firstMessage.trim().replace(/\n/g, " ")
  if (cleaned.length <= 50) return cleaned
  return `${cleaned.substring(0, 47)}...`
}
