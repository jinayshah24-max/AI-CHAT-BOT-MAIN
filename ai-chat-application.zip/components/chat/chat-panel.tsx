"use client"

import { useState, useRef, useEffect, useCallback } from "react"
import { useChat } from "@ai-sdk/react"
import { DefaultChatTransport } from "ai"
import { ChatMessage } from "./chat-message"
import { ChatInput } from "./chat-input"
import { WelcomeScreen } from "./welcome-screen"
import { ModelSelector } from "./model-selector"
import { DEFAULT_MODEL_ID } from "@/lib/ai/models"
import { generateTitle } from "@/lib/chat-store"
import type { ChatMetadata } from "@/lib/chat-store"
import { Menu, AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/theme-toggle"

/**
 * ChatPanel Component
 *
 * The main chat interface containing:
 * - Model selector in the header
 * - Message list with auto-scroll
 * - Welcome screen for empty chats
 * - Chat input at the bottom
 *
 * Uses the AI SDK's useChat hook with DefaultChatTransport
 * for streaming communication with the API route.
 */

interface ChatPanelProps {
  chatId: string
  initialModelId?: string
  onUpdateChat?: (metadata: Partial<ChatMetadata> & { id: string }) => void
  onToggleSidebar?: () => void
  showMenuButton?: boolean
}

export function ChatPanel({
  chatId,
  initialModelId,
  onUpdateChat,
  onToggleSidebar,
  showMenuButton,
}: ChatPanelProps) {
  const [modelId, setModelId] = useState(initialModelId || DEFAULT_MODEL_ID)
  const [input, setInput] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const scrollContainerRef = useRef<HTMLDivElement>(null)
  const hasSetTitle = useRef(false)

  const { messages, sendMessage, status, stop, error } = useChat({
    id: chatId,
    transport: new DefaultChatTransport({
      api: "/api/chat",
      prepareSendMessagesRequest: ({ id, messages: msgs }) => ({
        body: {
          messages: msgs,
          modelId,
          id,
        },
      }),
    }),
  })

  const isLoading = status === "streaming" || status === "submitted"

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }, [messages, status])

  // Set chat title from first user message
  useEffect(() => {
    if (messages.length > 0 && !hasSetTitle.current && onUpdateChat) {
      const firstUserMessage = messages.find((m) => m.role === "user")
      if (firstUserMessage) {
        const text = firstUserMessage.parts
          ?.filter(
            (p): p is { type: "text"; text: string } => p.type === "text"
          )
          .map((p) => p.text)
          .join("")
        if (text) {
          onUpdateChat({
            id: chatId,
            title: generateTitle(text),
            updatedAt: Date.now(),
          })
          hasSetTitle.current = true
        }
      }
    }
  }, [messages, chatId, onUpdateChat])

  // Reset title flag on chat change
  useEffect(() => {
    hasSetTitle.current = false
  }, [chatId])

  const handleSubmit = useCallback(() => {
    if (!input.trim()) return
    sendMessage({ text: input })
    setInput("")
    onUpdateChat?.({ id: chatId, updatedAt: Date.now() })
  }, [input, sendMessage, chatId, onUpdateChat])

  const handleSuggestion = useCallback(
    (suggestion: string) => {
      sendMessage({ text: suggestion })
      onUpdateChat?.({ id: chatId, updatedAt: Date.now() })
    },
    [sendMessage, chatId, onUpdateChat]
  )

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <header className="flex items-center justify-between px-4 py-2 border-b border-border bg-background/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="flex items-center gap-2">
          {showMenuButton && (
            <Button
              variant="ghost"
              size="icon"
              onClick={onToggleSidebar}
              className="h-8 w-8 lg:hidden"
              aria-label="Toggle sidebar"
            >
              <Menu className="h-4 w-4" />
            </Button>
          )}
          <ModelSelector
            selectedModelId={modelId}
            onModelChange={setModelId}
          />
        </div>
        <ThemeToggle />
      </header>

      {/* Error Banner */}
      {error && (
        <div className="mx-4 mt-2 rounded-lg border border-destructive/50 bg-destructive/10 p-3 flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
          <div className="text-sm text-destructive">
            <p className="font-medium">Something went wrong</p>
            <p className="mt-1 text-destructive/80">
              {error.message.includes("API key") ||
              error.message.includes("API_KEY") ||
              error.message.includes("401") ||
              error.message.includes("403")
                ? "Missing or invalid Google AI API key. Add your GOOGLE_GENERATIVE_AI_API_KEY in the Vars section. Get a free key at aistudio.google.com/apikey"
                : error.message || "An unexpected error occurred. Please try again."}
            </p>
          </div>
        </div>
      )}

      {/* Messages */}
      <div
        ref={scrollContainerRef}
        className="flex-1 overflow-y-auto scrollbar-thin"
      >
        {messages.length === 0 ? (
          <WelcomeScreen onSuggestionClick={handleSuggestion} />
        ) : (
          <div className="max-w-3xl mx-auto">
            {messages.map((message, index) => (
              <ChatMessage
                key={message.id}
                message={message}
                isStreaming={
                  isLoading &&
                  index === messages.length - 1 &&
                  message.role === "assistant"
                }
              />
            ))}
            <div ref={messagesEndRef} className="h-4" />
          </div>
        )}
      </div>

      {/* Input */}
      <div className="border-t border-border bg-background/80 backdrop-blur-sm">
        <div className="max-w-3xl mx-auto px-4 py-3">
          <ChatInput
            value={input}
            onChange={setInput}
            onSubmit={handleSubmit}
            onStop={stop}
            isLoading={isLoading}
          />
          <p className="text-xs text-muted-foreground text-center mt-2">
            AI can make mistakes. Verify important information.
          </p>
        </div>
      </div>
    </div>
  )
}
