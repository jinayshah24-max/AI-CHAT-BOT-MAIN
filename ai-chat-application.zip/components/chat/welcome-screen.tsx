"use client"

import { Sparkles, Code, BookOpen, Lightbulb } from "lucide-react"

/**
 * WelcomeScreen Component
 *
 * Displayed when a new chat is started with no messages.
 * Shows suggested prompts to help users get started.
 */

interface WelcomeScreenProps {
  onSuggestionClick: (suggestion: string) => void
}

const SUGGESTIONS = [
  {
    icon: Code,
    label: "Write Code",
    prompt: "Write a React hook for debouncing input values with TypeScript",
  },
  {
    icon: BookOpen,
    label: "Explain Concept",
    prompt:
      "Explain how transformers work in neural networks, with a simple analogy",
  },
  {
    icon: Lightbulb,
    label: "Brainstorm Ideas",
    prompt:
      "Help me brainstorm a side project idea using AI and web technologies",
  },
  {
    icon: Sparkles,
    label: "Analyze Data",
    prompt:
      "What are the best practices for building a scalable REST API in Node.js?",
  },
]

export function WelcomeScreen({ onSuggestionClick }: WelcomeScreenProps) {
  return (
    <div className="flex flex-col items-center justify-center h-full px-4 py-12">
      <div className="flex items-center gap-3 mb-3">
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10">
          <Sparkles className="h-6 w-6 text-primary" />
        </div>
      </div>

      <h1 className="text-2xl font-semibold text-foreground mb-2 text-balance text-center">
        AI Research Assistant
      </h1>
      <p className="text-muted-foreground text-sm mb-10 max-w-md text-center text-balance">
        A multi-provider AI chat platform for research, coding, and learning.
        Select a model and start exploring.
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-xl">
        {SUGGESTIONS.map((suggestion) => (
          <button
            key={suggestion.label}
            type="button"
            onClick={() => onSuggestionClick(suggestion.prompt)}
            className="flex items-start gap-3 rounded-xl border border-border bg-card p-4 text-left transition-all hover:bg-accent hover:border-primary/20 group"
          >
            <div className="flex-shrink-0 mt-0.5">
              <suggestion.icon className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground mb-0.5">
                {suggestion.label}
              </p>
              <p className="text-xs text-muted-foreground line-clamp-2">
                {suggestion.prompt}
              </p>
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}
