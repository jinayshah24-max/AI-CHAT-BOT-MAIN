"use client"

import { useRef, useCallback, type KeyboardEvent } from "react"
import { ArrowUp, Square } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

/**
 * ChatInput Component
 *
 * A textarea-based input with:
 * - Auto-resizing textarea
 * - Submit on Enter (Shift+Enter for new line)
 * - Send/Stop button
 * - Disabled state during streaming
 */

interface ChatInputProps {
  value: string
  onChange: (value: string) => void
  onSubmit: () => void
  onStop?: () => void
  isLoading: boolean
  placeholder?: string
}

export function ChatInput({
  value,
  onChange,
  onSubmit,
  onStop,
  isLoading,
  placeholder = "Message AI...",
}: ChatInputProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  const handleInput = useCallback(() => {
    const textarea = textareaRef.current
    if (textarea) {
      textarea.style.height = "auto"
      textarea.style.height = `${Math.min(textarea.scrollHeight, 200)}px`
    }
  }, [])

  const handleKeyDown = useCallback(
    (e: KeyboardEvent<HTMLTextAreaElement>) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault()
        if (value.trim() && !isLoading) {
          onSubmit()
          // Reset height
          if (textareaRef.current) {
            textareaRef.current.style.height = "auto"
          }
        }
      }
    },
    [value, isLoading, onSubmit]
  )

  return (
    <div className="relative flex items-end gap-2 rounded-2xl border border-border bg-card p-2 shadow-sm focus-within:border-primary/50 focus-within:ring-1 focus-within:ring-primary/20 transition-all">
      <textarea
        ref={textareaRef}
        value={value}
        onChange={(e) => {
          onChange(e.target.value)
          handleInput()
        }}
        onKeyDown={handleKeyDown}
        placeholder={placeholder}
        rows={1}
        className={cn(
          "flex-1 resize-none bg-transparent px-2 py-1.5 text-sm leading-relaxed",
          "placeholder:text-muted-foreground",
          "focus:outline-none",
          "max-h-[200px] scrollbar-thin"
        )}
        disabled={isLoading}
        aria-label="Chat message input"
      />

      {isLoading ? (
        <Button
          type="button"
          size="icon"
          variant="ghost"
          onClick={onStop}
          className="h-8 w-8 shrink-0 rounded-lg text-muted-foreground hover:text-foreground"
          aria-label="Stop generating"
        >
          <Square className="h-4 w-4 fill-current" />
        </Button>
      ) : (
        <Button
          type="button"
          size="icon"
          onClick={() => {
            if (value.trim()) {
              onSubmit()
              if (textareaRef.current) {
                textareaRef.current.style.height = "auto"
              }
            }
          }}
          disabled={!value.trim()}
          className="h-8 w-8 shrink-0 rounded-lg"
          aria-label="Send message"
        >
          <ArrowUp className="h-4 w-4" />
        </Button>
      )}
    </div>
  )
}
