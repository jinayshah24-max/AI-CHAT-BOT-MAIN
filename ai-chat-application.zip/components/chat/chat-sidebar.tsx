"use client"

import { MessageSquarePlus, Trash2, MessageSquare } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import type { ChatMetadata } from "@/lib/chat-store"

/**
 * ChatSidebar Component
 *
 * Displays the list of chat conversations with:
 * - New chat button
 * - Chat history list sorted by most recent
 * - Active chat highlighting
 * - Delete functionality
 * - Grouped by recency (Today, Previous 7 Days, Older)
 */

interface ChatSidebarProps {
  chats: ChatMetadata[]
  activeChatId: string | null
  onSelectChat: (chatId: string) => void
  onNewChat: () => void
  onDeleteChat: (chatId: string) => void
  className?: string
}

function groupChatsByDate(chats: ChatMetadata[]) {
  const now = Date.now()
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  const todayTs = today.getTime()
  const sevenDaysAgo = todayTs - 7 * 24 * 60 * 60 * 1000

  const groups: { label: string; chats: ChatMetadata[] }[] = [
    { label: "Today", chats: [] },
    { label: "Previous 7 Days", chats: [] },
    { label: "Older", chats: [] },
  ]

  for (const chat of chats) {
    if (chat.updatedAt >= todayTs) {
      groups[0].chats.push(chat)
    } else if (chat.updatedAt >= sevenDaysAgo) {
      groups[1].chats.push(chat)
    } else {
      groups[2].chats.push(chat)
    }
  }

  return groups.filter((g) => g.chats.length > 0)
}

export function ChatSidebar({
  chats,
  activeChatId,
  onSelectChat,
  onNewChat,
  onDeleteChat,
  className,
}: ChatSidebarProps) {
  const sortedChats = [...chats].sort((a, b) => b.updatedAt - a.updatedAt)
  const groups = groupChatsByDate(sortedChats)

  return (
    <div className={cn("flex flex-col h-full", className)}>
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-sidebar-border">
        <h2 className="text-sm font-semibold text-sidebar-foreground">
          Chat History
        </h2>
        <Button
          variant="ghost"
          size="icon"
          onClick={onNewChat}
          className="h-8 w-8 text-sidebar-foreground hover:text-sidebar-primary"
          aria-label="New chat"
        >
          <MessageSquarePlus className="h-4 w-4" />
        </Button>
      </div>

      {/* Chat list */}
      <ScrollArea className="flex-1">
        <div className="px-2 py-2">
          {groups.length === 0 ? (
            <div className="px-3 py-8 text-center">
              <MessageSquare className="h-8 w-8 mx-auto mb-2 text-muted-foreground/50" />
              <p className="text-xs text-muted-foreground">
                No conversations yet
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                Start a new chat to begin
              </p>
            </div>
          ) : (
            groups.map((group) => (
              <div key={group.label} className="mb-4">
                <span className="block px-3 py-1.5 text-xs font-medium text-muted-foreground/70 uppercase tracking-wider">
                  {group.label}
                </span>
                {group.chats.map((chat) => (
                  <div
                    key={chat.id}
                    role="button"
                    tabIndex={0}
                    onClick={() => onSelectChat(chat.id)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" || e.key === " ") {
                        e.preventDefault()
                        onSelectChat(chat.id)
                      }
                    }}
                    className={cn(
                      "group flex items-center w-full rounded-lg px-3 py-2 text-left text-sm transition-colors cursor-pointer",
                      chat.id === activeChatId
                        ? "bg-sidebar-accent text-sidebar-accent-foreground"
                        : "text-sidebar-foreground hover:bg-sidebar-accent/50"
                    )}
                  >
                    <span className="flex-1 truncate">{chat.title}</span>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation()
                        onDeleteChat(chat.id)
                      }}
                      className="opacity-0 group-hover:opacity-100 ml-2 p-1 rounded hover:bg-destructive/10 hover:text-destructive transition-all"
                      aria-label={`Delete chat: ${chat.title}`}
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                ))}
              </div>
            ))
          )}
        </div>
      </ScrollArea>
    </div>
  )
}
