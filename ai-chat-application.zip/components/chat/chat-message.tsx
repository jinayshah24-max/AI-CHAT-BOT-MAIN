"use client"

import { memo } from "react"
import type { UIMessage } from "ai"
import { Bot, User, Copy, Check } from "lucide-react"
import { useState, useCallback } from "react"
import { cn } from "@/lib/utils"
import { MarkdownRenderer } from "./markdown-renderer"

/**
 * ChatMessage Component
 *
 * Renders a single chat message with:
 * - Role-specific styling (user vs assistant)
 * - Avatar icons
 * - Markdown rendering for assistant messages
 * - Copy-to-clipboard functionality
 * - Streaming indicator
 */

interface ChatMessageProps {
  message: UIMessage
  isStreaming?: boolean
}

function getMessageText(message: UIMessage): string {
  if (!message.parts || !Array.isArray(message.parts)) return ""
  return message.parts
    .filter((p): p is { type: "text"; text: string } => p.type === "text")
    .map((p) => p.text)
    .join("")
}

export const ChatMessage = memo(function ChatMessage({
  message,
  isStreaming,
}: ChatMessageProps) {
  const [copied, setCopied] = useState(false)
  const isUser = message.role === "user"
  const text = getMessageText(message)

  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }, [text])

  if (!text && !isStreaming) return null

  return (
    <div
      className={cn(
        "group flex gap-4 py-6 px-4",
        isUser ? "justify-end" : "justify-start"
      )}
    >
      {!isUser && (
        <div className="flex-shrink-0 mt-0.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 text-primary">
            <Bot className="h-4 w-4" />
          </div>
        </div>
      )}

      <div
        className={cn(
          "flex flex-col max-w-[85%] md:max-w-[75%]",
          isUser && "items-end"
        )}
      >
        <div
          className={cn(
            "rounded-2xl px-4 py-3",
            isUser
              ? "bg-primary text-primary-foreground"
              : "bg-transparent"
          )}
        >
          {isUser ? (
            <p className="text-sm leading-relaxed whitespace-pre-wrap">
              {text}
            </p>
          ) : (
            <>
              <MarkdownRenderer content={text} />
              {isStreaming && !text && (
                <div className="flex items-center gap-1.5 py-1">
                  <div className="h-2 w-2 rounded-full bg-primary/60 animate-pulse" />
                  <div className="h-2 w-2 rounded-full bg-primary/60 animate-pulse [animation-delay:150ms]" />
                  <div className="h-2 w-2 rounded-full bg-primary/60 animate-pulse [animation-delay:300ms]" />
                </div>
              )}
              {isStreaming && text && (
                <span className="inline-block w-0.5 h-4 bg-primary ml-0.5 animate-blink" />
              )}
            </>
          )}
        </div>

        {/* Action buttons - visible on hover */}
        {!isUser && text && !isStreaming && (
          <div className="flex items-center gap-1 mt-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
            <button
              type="button"
              onClick={handleCopy}
              className="flex items-center gap-1 px-2 py-1 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
              aria-label="Copy message"
            >
              {copied ? (
                <Check className="h-3 w-3" />
              ) : (
                <Copy className="h-3 w-3" />
              )}
              <span>{copied ? "Copied" : "Copy"}</span>
            </button>
          </div>
        )}
      </div>

      {isUser && (
        <div className="flex-shrink-0 mt-0.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-secondary text-secondary-foreground">
            <User className="h-4 w-4" />
          </div>
        </div>
      )}
    </div>
  )
})
