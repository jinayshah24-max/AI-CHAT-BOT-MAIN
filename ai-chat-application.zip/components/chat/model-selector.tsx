"use client"

import { ChevronDown, Sparkles } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { MODEL_PROVIDERS, getModelById, type AIModel } from "@/lib/ai/models"
import { cn } from "@/lib/utils"

/**
 * ModelSelector Component
 *
 * A dropdown menu for selecting the active AI model.
 * Models are grouped by provider (OpenAI, Anthropic, Google, etc.).
 * Shows the current model name and provider in the trigger button.
 */

interface ModelSelectorProps {
  selectedModelId: string
  onModelChange: (modelId: string) => void
  className?: string
}

export function ModelSelector({
  selectedModelId,
  onModelChange,
  className,
}: ModelSelectorProps) {
  const selectedModel = getModelById(selectedModelId)

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          className={cn(
            "gap-2 px-3 py-2 h-auto font-medium text-sm",
            className
          )}
        >
          <Sparkles className="h-4 w-4 text-primary" />
          <span className="truncate max-w-[180px]">
            {selectedModel?.name || "Select Model"}
          </span>
          <ChevronDown className="h-3 w-3 text-muted-foreground" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-72">
        {MODEL_PROVIDERS.map((provider, pi) => (
          <div key={provider.id}>
            {pi > 0 && <DropdownMenuSeparator />}
            <DropdownMenuLabel className="text-xs text-muted-foreground font-normal">
              {provider.name}
            </DropdownMenuLabel>
            {provider.models.map((model: AIModel) => (
              <DropdownMenuItem
                key={model.id}
                onClick={() => onModelChange(model.id)}
                className={cn(
                  "flex flex-col items-start gap-0.5 py-2 cursor-pointer",
                  model.id === selectedModelId && "bg-accent"
                )}
              >
                <span className="font-medium text-sm">{model.name}</span>
                <span className="text-xs text-muted-foreground">
                  {model.description}
                </span>
              </DropdownMenuItem>
            ))}
          </div>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
