"use client"

import React from "react"
import { JSX } from "react/jsx-runtime"

import { memo, useState, useCallback } from "react"
import { Check, Copy } from "lucide-react"
import { cn } from "@/lib/utils"

/**
 * Markdown Renderer
 *
 * A lightweight markdown-to-JSX renderer that handles:
 * - Code blocks with syntax highlighting (via class names) and copy buttons
 * - Inline code, bold, italic, strikethrough
 * - Headings, lists, blockquotes, horizontal rules
 * - Links and tables
 *
 * We avoid heavy dependencies like react-markdown + remark by
 * implementing a simple block-level then inline-level parser.
 */

interface MarkdownRendererProps {
  content: string
  className?: string
}

function CodeBlock({ language, code }: { language: string; code: string }) {
  const [copied, setCopied] = useState(false)

  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText(code)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }, [code])

  return (
    <div className="group relative my-3 rounded-lg border border-border bg-muted/50 overflow-hidden">
      <div className="flex items-center justify-between px-4 py-2 border-b border-border bg-muted/80">
        <span className="text-xs font-mono text-muted-foreground">
          {language || "text"}
        </span>
        <button
          type="button"
          onClick={handleCopy}
          className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
          aria-label="Copy code"
        >
          {copied ? (
            <>
              <Check className="h-3.5 w-3.5" />
              <span>Copied</span>
            </>
          ) : (
            <>
              <Copy className="h-3.5 w-3.5" />
              <span>Copy</span>
            </>
          )}
        </button>
      </div>
      <pre className="overflow-x-auto p-4">
        <code className="text-sm font-mono leading-relaxed text-foreground">
          {code}
        </code>
      </pre>
    </div>
  )
}

/**
 * Parses inline markdown elements (bold, italic, code, links, strikethrough).
 */
function parseInline(text: string): React.ReactNode[] {
  const nodes: React.ReactNode[] = []
  // Regex for inline patterns: bold, italic, inline code, links, strikethrough
  const regex =
    /(\*\*(.+?)\*\*)|(\*(.+?)\*)|(`([^`]+)`)|\[([^\]]+)\]\(([^)]+)\)|(~~(.+?)~~)/g
  let lastIndex = 0
  let match: RegExpExecArray | null = null

  // biome-ignore lint: using exec in a loop is fine
  while ((match = regex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      nodes.push(text.slice(lastIndex, match.index))
    }

    if (match[1]) {
      // bold
      nodes.push(
        <strong key={match.index} className="font-semibold">
          {match[2]}
        </strong>
      )
    } else if (match[3]) {
      // italic
      nodes.push(<em key={match.index}>{match[4]}</em>)
    } else if (match[5]) {
      // inline code
      nodes.push(
        <code
          key={match.index}
          className="rounded bg-muted px-1.5 py-0.5 text-sm font-mono"
        >
          {match[6]}
        </code>
      )
    } else if (match[7]) {
      // link
      nodes.push(
        <a
          key={match.index}
          href={match[8]}
          target="_blank"
          rel="noopener noreferrer"
          className="text-primary underline underline-offset-2 hover:text-primary/80"
        >
          {match[7]}
        </a>
      )
    } else if (match[9]) {
      // strikethrough
      nodes.push(
        <del key={match.index} className="text-muted-foreground">
          {match[10]}
        </del>
      )
    }

    lastIndex = match.index + match[0].length
  }

  if (lastIndex < text.length) {
    nodes.push(text.slice(lastIndex))
  }

  return nodes.length > 0 ? nodes : [text]
}

/**
 * Renders a single block of markdown content.
 */
function renderBlock(line: string, index: number): React.ReactNode {
  // Headings
  const headingMatch = line.match(/^(#{1,4})\s+(.+)/)
  if (headingMatch) {
    const level = headingMatch[1].length
    const text = headingMatch[2]
    const Tag = `h${level}` as keyof JSX.IntrinsicElements
    const sizes: Record<number, string> = {
      1: "text-2xl font-bold mt-6 mb-3",
      2: "text-xl font-semibold mt-5 mb-2",
      3: "text-lg font-semibold mt-4 mb-2",
      4: "text-base font-semibold mt-3 mb-1",
    }
    return (
      <Tag key={index} className={sizes[level]}>
        {parseInline(text)}
      </Tag>
    )
  }

  // Horizontal rule
  if (/^(-{3,}|_{3,}|\*{3,})$/.test(line.trim())) {
    return <hr key={index} className="my-4 border-border" />
  }

  // Blockquote
  if (line.startsWith("> ")) {
    return (
      <blockquote
        key={index}
        className="border-l-3 border-border pl-4 my-2 text-muted-foreground italic"
      >
        {parseInline(line.slice(2))}
      </blockquote>
    )
  }

  // Unordered list item
  if (/^[-*+]\s/.test(line)) {
    return (
      <li key={index} className="ml-5 list-disc mb-1">
        {parseInline(line.replace(/^[-*+]\s/, ""))}
      </li>
    )
  }

  // Ordered list item
  const olMatch = line.match(/^(\d+)\.\s(.+)/)
  if (olMatch) {
    return (
      <li key={index} className="ml-5 list-decimal mb-1">
        {parseInline(olMatch[2])}
      </li>
    )
  }

  // Regular paragraph
  if (line.trim()) {
    return (
      <p key={index} className="mb-3 last:mb-0">
        {parseInline(line)}
      </p>
    )
  }

  return null
}

export const MarkdownRenderer = memo(function MarkdownRenderer({
  content,
  className,
}: MarkdownRendererProps) {
  if (!content) return null

  const elements: React.ReactNode[] = []
  const lines = content.split("\n")
  let i = 0

  while (i < lines.length) {
    // Code block detection
    if (lines[i].startsWith("```")) {
      const language = lines[i].slice(3).trim()
      const codeLines: string[] = []
      i++
      while (i < lines.length && !lines[i].startsWith("```")) {
        codeLines.push(lines[i])
        i++
      }
      i++ // skip closing ```
      elements.push(
        <CodeBlock
          key={`code-${i}`}
          language={language}
          code={codeLines.join("\n")}
        />
      )
      continue
    }

    // Table detection
    if (lines[i].includes("|") && lines[i].trim().startsWith("|")) {
      const tableLines: string[] = []
      while (
        i < lines.length &&
        lines[i].includes("|") &&
        lines[i].trim().startsWith("|")
      ) {
        tableLines.push(lines[i])
        i++
      }
      if (tableLines.length >= 2) {
        // Parse header row
        const headerCells = tableLines[0]
          .split("|")
          .filter((c) => c.trim())
          .map((c) => c.trim())
        // Skip separator row (index 1)
        const bodyRows = tableLines.slice(2).map((row) =>
          row
            .split("|")
            .filter((c) => c.trim())
            .map((c) => c.trim())
        )

        elements.push(
          <div key={`table-${i}`} className="my-3 overflow-x-auto">
            <table className="w-full border-collapse text-sm">
              <thead>
                <tr>
                  {headerCells.map((cell, ci) => (
                    <th
                      key={ci}
                      className="border border-border bg-muted px-3 py-2 text-left font-semibold"
                    >
                      {parseInline(cell)}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {bodyRows.map((row, ri) => (
                  <tr key={ri}>
                    {row.map((cell, ci) => (
                      <td key={ci} className="border border-border px-3 py-2">
                        {parseInline(cell)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )
        continue
      }
    }

    // Regular block
    const block = renderBlock(lines[i], i)
    if (block) {
      elements.push(block)
    }
    i++
  }

  return (
    <div className={cn("prose-chat text-sm leading-relaxed", className)}>
      {elements}
    </div>
  )
})
