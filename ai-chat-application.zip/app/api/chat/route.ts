/**
 * Chat API Route Handler
 *
 * Uses @ai-sdk/google directly with your own GOOGLE_GENERATIVE_AI_API_KEY.
 * Get a free key at https://aistudio.google.com/apikey
 */

import {
  streamText,
  convertToModelMessages,
  type UIMessage,
  consumeStream,
} from "ai"
import { google } from "@ai-sdk/google"

export const maxDuration = 60

const SYSTEM_PROMPT = `You are a helpful, knowledgeable AI research assistant. You provide clear, accurate, and well-structured responses.

When writing code:
- Use proper syntax highlighting with language identifiers in code blocks
- Provide complete, runnable examples when possible
- Add brief comments explaining key logic

When explaining concepts:
- Use clear headings and structure
- Break complex topics into digestible parts
- Provide relevant examples

Always be honest about uncertainty and limitations.`

export async function POST(req: Request) {
  try {
    const {
      messages,
      modelId,
    }: {
      messages: UIMessage[]
      modelId?: string
    } = await req.json()

    // Default to gemini-2.5-flash, strip any prefix
    const rawId = modelId || "gemini-2.5-flash"
    const resolvedModel = rawId.includes("/") ? rawId.split("/")[1] : rawId

    const result = streamText({
      model: google(resolvedModel),
      system: SYSTEM_PROMPT,
      messages: await convertToModelMessages(messages),
      abortSignal: req.signal,
      maxTokens: 4096,
    })

    return result.toUIMessageStreamResponse({
      originalMessages: messages,
      consumeSseStream: consumeStream,
    })
  } catch (error: unknown) {
    const message =
      error instanceof Error ? error.message : "An unexpected error occurred"

    if (
      message.includes("API key") ||
      message.includes("API_KEY") ||
      message.includes("401") ||
      message.includes("403")
    ) {
      return new Response(
        JSON.stringify({
          error:
            "Missing or invalid Google AI API key. Please add your GOOGLE_GENERATIVE_AI_API_KEY in the Vars section of the sidebar. Get a free key at https://aistudio.google.com/apikey",
        }),
        { status: 401, headers: { "Content-Type": "application/json" } }
      )
    }

    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }
}
