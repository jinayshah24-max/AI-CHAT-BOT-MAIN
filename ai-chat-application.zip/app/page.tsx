"use client"

import { useState, useCallback } from "react"
import { ChatPanel } from "@/components/chat/chat-panel"
import { ChatSidebar } from "@/components/chat/chat-sidebar"
import { generateChatId, type ChatMetadata } from "@/lib/chat-store"
import { DEFAULT_MODEL_ID } from "@/lib/ai/models"
import { cn } from "@/lib/utils"
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet"

/**
 * Main Chat Page
 *
 * Orchestrates the full chat application:
 * - Manages chat list state (would be DB-backed in production)
 * - Controls sidebar visibility (responsive: sheet on mobile, fixed on desktop)
 * - Routes between active chats
 *
 * Architecture note:
 * The chat messages themselves are managed by useChat inside ChatPanel.
 * This page only manages chat metadata (titles, IDs, ordering).
 */

export default function ChatPage() {
  const [chats, setChats] = useState<ChatMetadata[]>([])
  const [activeChatId, setActiveChatId] = useState<string | null>(null)
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const createNewChat = useCallback(() => {
    const id = generateChatId()
    const newChat: ChatMetadata = {
      id,
      title: "New Conversation",
      modelId: DEFAULT_MODEL_ID,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    }
    setChats((prev) => [newChat, ...prev])
    setActiveChatId(id)
    setSidebarOpen(false)
    return id
  }, [])

  const handleSelectChat = useCallback((chatId: string) => {
    setActiveChatId(chatId)
    setSidebarOpen(false)
  }, [])

  const handleDeleteChat = useCallback(
    (chatId: string) => {
      setChats((prev) => prev.filter((c) => c.id !== chatId))
      if (activeChatId === chatId) {
        setActiveChatId(null)
      }
    },
    [activeChatId]
  )

  const handleUpdateChat = useCallback(
    (update: Partial<ChatMetadata> & { id: string }) => {
      setChats((prev) =>
        prev.map((c) => (c.id === update.id ? { ...c, ...update } : c))
      )
    },
    []
  )

  // Auto-create a chat if none exists when user starts typing
  const ensureActiveChat = useCallback(() => {
    if (!activeChatId) {
      return createNewChat()
    }
    return activeChatId
  }, [activeChatId, createNewChat])

  // Ensure we always have an active chat
  const currentChatId = activeChatId || ensureActiveChat()
  const currentChat = chats.find((c) => c.id === currentChatId)

  return (
    <div className="flex h-dvh overflow-hidden">
      {/* Desktop sidebar */}
      <aside
        className={cn(
          "hidden lg:flex w-72 flex-col border-r border-sidebar-border bg-sidebar shrink-0"
        )}
      >
        <ChatSidebar
          chats={chats}
          activeChatId={activeChatId}
          onSelectChat={handleSelectChat}
          onNewChat={createNewChat}
          onDeleteChat={handleDeleteChat}
        />
      </aside>

      {/* Mobile sidebar (sheet) */}
      <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
        <SheetContent side="left" className="w-72 p-0 bg-sidebar">
          <SheetTitle className="sr-only">Chat History</SheetTitle>
          <ChatSidebar
            chats={chats}
            activeChatId={activeChatId}
            onSelectChat={handleSelectChat}
            onNewChat={createNewChat}
            onDeleteChat={handleDeleteChat}
          />
        </SheetContent>
      </Sheet>

      {/* Main chat area */}
      <main className="flex-1 flex flex-col min-w-0">
        <ChatPanel
          key={currentChatId}
          chatId={currentChatId}
          initialModelId={currentChat?.modelId}
          onUpdateChat={handleUpdateChat}
          onToggleSidebar={() => setSidebarOpen(true)}
          showMenuButton
        />
      </main>
    </div>
  )
}
